package by.bsu.example.filter;

public enum ClientType {
GUEST, USER, ADMINISTRATOR
}