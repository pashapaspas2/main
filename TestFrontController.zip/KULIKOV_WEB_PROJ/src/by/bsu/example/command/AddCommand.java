package by.bsu.example.command;

import javax.servlet.http.HttpServletRequest;

public class AddCommand implements ActionCommand {

	@Override
	public String execute(HttpServletRequest request) {
		return null;

	}
}
